
console.log(isLandscape(300, 600));

function isLandscape(width, height) {
  return (width > height);
}