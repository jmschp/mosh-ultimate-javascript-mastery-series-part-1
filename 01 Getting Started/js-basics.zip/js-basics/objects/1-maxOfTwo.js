
let numbet = max(1, 2);
console.log(number);

function max(a, b) { 
  return (a > b) ? a : b;
}