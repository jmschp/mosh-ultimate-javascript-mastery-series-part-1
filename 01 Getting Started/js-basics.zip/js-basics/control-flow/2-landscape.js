
console.log(isLandscape(800, 700));

function isLandscape(width, height) {
  return (width > height); 
}